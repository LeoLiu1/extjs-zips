/**
 * @private
 */
Ext.define('Ext.pivot.plugin.configurator.store.Select', {
    extend: 'Ext.data.ArrayStore',
    alias: 'store.pivotselect',

    model: 'Ext.pivot.plugin.configurator.model.Select'
});