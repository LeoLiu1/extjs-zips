# mzPivotGrid/sass

This folder contains SASS files of various kinds, organized in sub-folders:

    mzPivotGrid/sass/etc
    mzPivotGrid/sass/src
    mzPivotGrid/sass/var
