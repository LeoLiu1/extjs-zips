/**
 * Portuguese (Brasil) translation by Rivaldo C Carvalho.
 *
 */

Ext.define('Ext.locale.pt_BR.pivot.Grid', {
    override: 'Ext.pivot.Grid',

    textTotalTpl:       'Total ({name})',
    textGrandTotalTpl:  'Total Geral'
});
