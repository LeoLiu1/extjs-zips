Ext.define('Ext.locale.da.pivot.Aggregators', {
    override: 'Ext.pivot.Aggregators',

    customText:                 'Custom',
    sumText:                    'Sum',
    avgText:                    'Gns',
    countText:                  'Antal',
    minText:                    'Min',
    maxText:                    'Max',
    groupSumPercentageText:     'Gruppe sum procent',
    groupCountPercentageText:   'Gruppe antal procent',
    varianceText:               'Var',
    variancePText:              'Varp',
    stdDevText:                 'StdDev',
    stdDevPText:                'StdDevp'
});
