/**
 * Danish translation by Steen Ole Andersen
 *
 */

Ext.define('Ext.locale.da.pivot.Grid', {
    override: 'Ext.pivot.Grid',

    textTotalTpl:       'Total ({name})',
    textGrandTotalTpl:  'Grand total'
});
