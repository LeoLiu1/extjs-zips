/**
 * German translation by Daniel Grana
 *
 */

Ext.define('Ext.locale.de.pivot.Grid', {
    override: 'Ext.pivot.Grid',

    textTotalTpl:       'Summe ({name})',
    textGrandTotalTpl:  'Gesamtsumme'
});
