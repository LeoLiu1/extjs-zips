/**
 * French translation by Daniel Grana
 *
 */

Ext.define('Ext.locale.fr.pivot.Grid', {
    override: 'Ext.pivot.Grid',

    textTotalTpl:       'Total ({name})',
    textGrandTotalTpl:  'Total général'
});
