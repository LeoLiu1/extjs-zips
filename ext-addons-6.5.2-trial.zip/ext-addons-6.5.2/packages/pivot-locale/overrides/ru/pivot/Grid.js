/**
 * Russian translation by Alexey Kushnikov (akushnikov@outlook.com)
 *
 */

Ext.define('Ext.locale.ru.pivot.Grid', {
    override: 'Ext.pivot.Grid',

    textTotalTpl:       'Итого по ({name})',
    textGrandTotalTpl:  'ИТОГО'
});
