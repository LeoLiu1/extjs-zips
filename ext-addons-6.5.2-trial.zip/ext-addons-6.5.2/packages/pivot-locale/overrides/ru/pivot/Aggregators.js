Ext.define('Ext.locale.ru.pivot.Aggregators', {
    override: 'Ext.pivot.Aggregators',

    customText:                 'Custom',
    sumText:                    'Сумма',
    avgText:                    'Среднее',
    countText:                  'Количество',
    minText:                    'Минимум',
    maxText:                    'Максимум',
    groupSumPercentageText:     'Процент от суммы',
    groupCountPercentageText:   'Процент от количества',
    varianceText:               'Var',
    variancePText:              'Varp',
    stdDevText:                 'StdDev',
    stdDevPText:                'StdDevp'
});
