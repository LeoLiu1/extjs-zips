Ext.define('Ext.locale.ro.pivot.Grid', {
    override: 'Ext.pivot.Grid',

    textTotalTpl:       'Subtotal ({name})',
    textGrandTotalTpl:  'Total general'
});
