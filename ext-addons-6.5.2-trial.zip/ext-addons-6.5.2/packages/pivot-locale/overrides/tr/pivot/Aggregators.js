Ext.define('Ext.locale.tr.pivot.Aggregators', {
    override: 'Ext.pivot.Aggregators',

    customText:                 'Custom',
    sumText:                    'Topla',
    avgText:                    'Ort',
    countText:                  'Sayı',
    minText:                    'En Küçük',
    maxText:                    'En Büyük',
    groupSumPercentageText:     'Grup toplam yüzde',
    groupCountPercentageText:   'Grup sayı yüzde',
    varianceText:               'Var',
    variancePText:              'Varp',
    stdDevText:                 'StdDev',
    stdDevPText:                'StdDevp'
});
