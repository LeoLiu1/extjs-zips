/**
 * Turkish translation by Deniz Girginer
 *
 */

Ext.define('Ext.locale.tr.pivot.Grid', {
    override: 'Ext.pivot.Grid',

    textTotalTpl:       'Toplam ({name})',
    textGrandTotalTpl:  'Genel toplam',
    total:'Toplam',
    blank:'(boş)'
});
