Ext.define('Ext.locale.en.pivot.plugin.rangeeditor.Panel', {
    override: 'Ext.pivot.plugin.rangeeditor.Panel',

    titleText:      'Range editor',
    valueText:      'Value',
    fieldText:      'Source field is "{form.dataIndex}"',
    typeText:       'Type',
    okText:         'Ok',
    cancelText:     'Cancel'
});
