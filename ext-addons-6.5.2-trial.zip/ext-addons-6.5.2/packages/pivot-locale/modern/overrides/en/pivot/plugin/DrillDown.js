Ext.define('Ext.locale.en.pivot.plugin.DrillDown', {
    override: 'Ext.pivot.plugin.DrillDown',

    titleText: 'Drill down',
    doneText: 'Done'
});
