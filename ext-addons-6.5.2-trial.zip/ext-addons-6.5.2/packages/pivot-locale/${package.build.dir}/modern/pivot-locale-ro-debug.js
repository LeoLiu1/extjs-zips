Ext.define('Ext.locale.ro.pivot.Aggregators', {
    override: 'Ext.pivot.Aggregators',

    customText:                 'Custom',
    sumText:                    'Suma',
    avgText:                    'Media',
    countText:                  'Nr. de inregistrari',
    minText:                    'Minim',
    maxText:                    'Maxim',
    groupSumPercentageText:     '% din suma grupului',
    groupCountPercentageText:   '% din nr. de inregistrari al grupului',
    varianceText:               'Var',
    variancePText:              'Varp',
    stdDevText:                 'StdDev',
    stdDevPText:                'StdDevp'
});
Ext.define('Ext.locale.ro.pivot.Grid', {
    override: 'Ext.pivot.Grid',

    textTotalTpl:       'Subtotal ({name})',
    textGrandTotalTpl:  'Total general'
});
Ext.define('Ext.locale.ro.pivot.Aggregators', {
    override: 'Ext.pivot.Aggregators',

    customText:                 'Custom',
    sumText:                    'Suma',
    avgText:                    'Media',
    countText:                  'Nr. de inregistrari',
    minText:                    'Minim',
    maxText:                    'Maxim',
    groupSumPercentageText:     '% din suma grupului',
    groupCountPercentageText:   '% din nr. de inregistrari al grupului',
    varianceText:               'Var',
    variancePText:              'Varp',
    stdDevText:                 'StdDev',
    stdDevPText:                'StdDevp'
});
Ext.define('Ext.locale.ro.pivot.Grid', {
    override: 'Ext.pivot.Grid',

    textTotalTpl:       'Subtotal ({name})',
    textGrandTotalTpl:  'Total general'
});
