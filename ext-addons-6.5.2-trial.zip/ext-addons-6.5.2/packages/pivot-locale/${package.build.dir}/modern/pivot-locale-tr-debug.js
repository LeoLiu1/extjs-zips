Ext.define('Ext.locale.tr.pivot.Aggregators', {
    override: 'Ext.pivot.Aggregators',

    customText:                 'Custom',
    sumText:                    'Topla',
    avgText:                    'Ort',
    countText:                  'Sayı',
    minText:                    'En Küçük',
    maxText:                    'En Büyük',
    groupSumPercentageText:     'Grup toplam yüzde',
    groupCountPercentageText:   'Grup sayı yüzde',
    varianceText:               'Var',
    variancePText:              'Varp',
    stdDevText:                 'StdDev',
    stdDevPText:                'StdDevp'
});
/**
 * Turkish translation by Deniz Girginer
 *
 */

Ext.define('Ext.locale.tr.pivot.Grid', {
    override: 'Ext.pivot.Grid',

    textTotalTpl:       'Toplam ({name})',
    textGrandTotalTpl:  'Genel toplam',
    total:'Toplam',
    blank:'(boş)'
});
Ext.define('Ext.locale.tr.pivot.Aggregators', {
    override: 'Ext.pivot.Aggregators',

    customText:                 'Custom',
    sumText:                    'Topla',
    avgText:                    'Ort',
    countText:                  'Sayı',
    minText:                    'En Küçük',
    maxText:                    'En Büyük',
    groupSumPercentageText:     'Grup toplam yüzde',
    groupCountPercentageText:   'Grup sayı yüzde',
    varianceText:               'Var',
    variancePText:              'Varp',
    stdDevText:                 'StdDev',
    stdDevPText:                'StdDevp'
});
/**
 * Turkish translation by Deniz Girginer
 *
 */

Ext.define('Ext.locale.tr.pivot.Grid', {
    override: 'Ext.pivot.Grid',

    textTotalTpl:       'Toplam ({name})',
    textGrandTotalTpl:  'Genel toplam',
    total:'Toplam',
    blank:'(boş)'
});
