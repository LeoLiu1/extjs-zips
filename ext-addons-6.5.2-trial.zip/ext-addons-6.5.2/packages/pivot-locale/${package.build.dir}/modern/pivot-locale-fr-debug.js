Ext.define('Ext.locale.fr.pivot.Aggregators', {
    override: 'Ext.pivot.Aggregators',

    customText:                 'Custom',
    sumText:                    'Somme',
    avgText:                    'Moyenne',
    countText:                  'Nombre',
    minText:                    'Min',
    maxText:                    'Max',
    groupSumPercentageText:     'Pourcentage somme cumulée',
    groupCountPercentageText:   'Pourcentage nombre cumulé',
    varianceText:               'Var',
    variancePText:              'Varp',
    stdDevText:                 'StdDev',
    stdDevPText:                'StdDevp'
});
/**
 * French translation by Daniel Grana
 *
 */

Ext.define('Ext.locale.fr.pivot.Grid', {
    override: 'Ext.pivot.Grid',

    textTotalTpl:       'Total ({name})',
    textGrandTotalTpl:  'Total général'
});
Ext.define('Ext.locale.fr.pivot.Aggregators', {
    override: 'Ext.pivot.Aggregators',

    customText:                 'Custom',
    sumText:                    'Somme',
    avgText:                    'Moyenne',
    countText:                  'Nombre',
    minText:                    'Min',
    maxText:                    'Max',
    groupSumPercentageText:     'Pourcentage somme cumulée',
    groupCountPercentageText:   'Pourcentage nombre cumulé',
    varianceText:               'Var',
    variancePText:              'Varp',
    stdDevText:                 'StdDev',
    stdDevPText:                'StdDevp'
});
/**
 * French translation by Daniel Grana
 *
 */

Ext.define('Ext.locale.fr.pivot.Grid', {
    override: 'Ext.pivot.Grid',

    textTotalTpl:       'Total ({name})',
    textGrandTotalTpl:  'Total général'
});
