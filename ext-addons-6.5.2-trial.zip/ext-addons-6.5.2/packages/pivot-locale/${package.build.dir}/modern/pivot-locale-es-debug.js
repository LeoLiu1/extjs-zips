Ext.define('Ext.locale.es.pivot.Aggregators', {
    override: 'Ext.pivot.Aggregators',

    customText:                 'Custom',
    sumText:                    'Suma',
    avgText:                    'Prom',
    countText:                  'Cont',
    minText:                    'Min',
    maxText:                    'Max',
    groupSumPercentageText:     'Grupo % suma',
    groupCountPercentageText:   'Grupo % cont',
    varianceText:               'Var',
    variancePText:              'Varp',
    stdDevText:                 'StdDev',
    stdDevPText:                'StdDevp'
});
/**
 * Spanish translation by Gustavo Ruiz
 * The original translation was done for version 2.x.
 *
 */

Ext.define('Ext.locale.es.pivot.Grid', {
    override: 'Ext.pivot.Grid',

    textTotalTpl:       'Total ({name})',
    textGrandTotalTpl:  'Total General'
});
Ext.define('Ext.locale.es.pivot.Aggregators', {
    override: 'Ext.pivot.Aggregators',

    customText:                 'Custom',
    sumText:                    'Suma',
    avgText:                    'Prom',
    countText:                  'Cont',
    minText:                    'Min',
    maxText:                    'Max',
    groupSumPercentageText:     'Grupo % suma',
    groupCountPercentageText:   'Grupo % cont',
    varianceText:               'Var',
    variancePText:              'Varp',
    stdDevText:                 'StdDev',
    stdDevPText:                'StdDevp'
});
/**
 * Spanish translation by Gustavo Ruiz
 * The original translation was done for version 2.x.
 *
 */

Ext.define('Ext.locale.es.pivot.Grid', {
    override: 'Ext.pivot.Grid',

    textTotalTpl:       'Total ({name})',
    textGrandTotalTpl:  'Total General'
});
