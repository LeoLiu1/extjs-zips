Ext.define('Ext.locale.da.pivot.Aggregators', {
    override: 'Ext.pivot.Aggregators',

    customText:                 'Custom',
    sumText:                    'Sum',
    avgText:                    'Gns',
    countText:                  'Antal',
    minText:                    'Min',
    maxText:                    'Max',
    groupSumPercentageText:     'Gruppe sum procent',
    groupCountPercentageText:   'Gruppe antal procent',
    varianceText:               'Var',
    variancePText:              'Varp',
    stdDevText:                 'StdDev',
    stdDevPText:                'StdDevp'
});
/**
 * Danish translation by Steen Ole Andersen
 *
 */

Ext.define('Ext.locale.da.pivot.Grid', {
    override: 'Ext.pivot.Grid',

    textTotalTpl:       'Total ({name})',
    textGrandTotalTpl:  'Grand total'
});
Ext.define('Ext.locale.da.pivot.Aggregators', {
    override: 'Ext.pivot.Aggregators',

    customText:                 'Custom',
    sumText:                    'Sum',
    avgText:                    'Gns',
    countText:                  'Antal',
    minText:                    'Min',
    maxText:                    'Max',
    groupSumPercentageText:     'Gruppe sum procent',
    groupCountPercentageText:   'Gruppe antal procent',
    varianceText:               'Var',
    variancePText:              'Varp',
    stdDevText:                 'StdDev',
    stdDevPText:                'StdDevp'
});
/**
 * Danish translation by Steen Ole Andersen
 *
 */

Ext.define('Ext.locale.da.pivot.Grid', {
    override: 'Ext.pivot.Grid',

    textTotalTpl:       'Total ({name})',
    textGrandTotalTpl:  'Grand total'
});
