Ext.define('Ext.locale.ru.pivot.Aggregators', {
    override: 'Ext.pivot.Aggregators',

    customText:                 'Custom',
    sumText:                    'Сумма',
    avgText:                    'Среднее',
    countText:                  'Количество',
    minText:                    'Минимум',
    maxText:                    'Максимум',
    groupSumPercentageText:     'Процент от суммы',
    groupCountPercentageText:   'Процент от количества',
    varianceText:               'Var',
    variancePText:              'Varp',
    stdDevText:                 'StdDev',
    stdDevPText:                'StdDevp'
});
/**
 * Russian translation by Alexey Kushnikov (akushnikov@outlook.com)
 *
 */

Ext.define('Ext.locale.ru.pivot.Grid', {
    override: 'Ext.pivot.Grid',

    textTotalTpl:       'Итого по ({name})',
    textGrandTotalTpl:  'ИТОГО'
});
Ext.define('Ext.locale.ru.pivot.Aggregators', {
    override: 'Ext.pivot.Aggregators',

    customText:                 'Custom',
    sumText:                    'Сумма',
    avgText:                    'Среднее',
    countText:                  'Количество',
    minText:                    'Минимум',
    maxText:                    'Максимум',
    groupSumPercentageText:     'Процент от суммы',
    groupCountPercentageText:   'Процент от количества',
    varianceText:               'Var',
    variancePText:              'Varp',
    stdDevText:                 'StdDev',
    stdDevPText:                'StdDevp'
});
/**
 * Russian translation by Alexey Kushnikov (akushnikov@outlook.com)
 *
 */

Ext.define('Ext.locale.ru.pivot.Grid', {
    override: 'Ext.pivot.Grid',

    textTotalTpl:       'Итого по ({name})',
    textGrandTotalTpl:  'ИТОГО'
});
