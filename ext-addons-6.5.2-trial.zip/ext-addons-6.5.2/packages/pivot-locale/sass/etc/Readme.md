# pivot-locale/sass/etc

This folder contains miscellaneous SASS files. Unlike `"pivot-locale/sass/etc"`, these files
need to be used explicitly.
