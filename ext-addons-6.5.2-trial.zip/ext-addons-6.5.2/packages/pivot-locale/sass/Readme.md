# pivot-locale/sass

This folder contains SASS files of various kinds, organized in sub-folders:

    pivot-locale/sass/etc
    pivot-locale/sass/src
    pivot-locale/sass/var
