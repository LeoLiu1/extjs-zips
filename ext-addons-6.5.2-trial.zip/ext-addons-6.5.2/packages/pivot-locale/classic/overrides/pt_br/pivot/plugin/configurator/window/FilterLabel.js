Ext.define('Ext.locale.pt_br.pivot.plugin.configurator.window.FilterLabel',{
    override:           'Ext.pivot.plugin.configurator.window.FilterLabel',

    titleText:          'Filtra Rótulo ({0})',
    fieldText:          'Mostrar itens para os quais o rótulo é',
    caseSensitiveText:  'Maíúscula e minúscula'
});
