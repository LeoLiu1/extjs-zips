Ext.define('Ext.locale.pt_br.pivot.plugin.configurator.window.FilterValue',{
    override:       'Ext.pivot.plugin.configurator.window.FilterValue',
    titleText:      'Filtra valor ({0})',
    fieldText:      'Mostrar itens para os quais o valor é'
});