Ext.define('Ext.locale.pt_br.pivot.plugin.configurator.window.FilterTop',{
    override:       'Ext.pivot.plugin.configurator.window.FilterTop',

    titleText:      'Filtra top 10 ({0})',
    fieldText:      'Mostrar',
    sortResultsText:'Ordenar os resultados'
});