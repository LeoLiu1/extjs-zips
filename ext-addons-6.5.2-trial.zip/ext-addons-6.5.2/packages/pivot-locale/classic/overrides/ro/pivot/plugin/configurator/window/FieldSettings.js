Ext.define('Ext.locale.ro.pivot.plugin.configurator.window.FieldSettings', {
    override: 'Ext.pivot.plugin.configurator.window.FieldSettings',

    title:              'Configuratie camp',
    formatText:         'Afiseaza ca',
    summarizeByText:    'Formula de calcul',
    customNameText:     'Redenumeste',
    sourceNameText:     'Sursa',
    alignText:          'Aliniere',
    alignLeftText:      'Stanga',
    alignCenterText:    'Centru',
    alignRightText:     'Dreapta'
});
