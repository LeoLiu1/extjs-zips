Ext.define('Ext.locale.ro.pivot.plugin.configurator.window.FilterLabel',{
    override: 'Ext.pivot.plugin.configurator.window.FilterLabel',

    titleText:          'Filtreaza etichetele ({0})',
    fieldText:          'Arata inregistrarile pt care eticheta',
    caseSensitiveText:  'Cautare exacta'
});