Ext.define('Ext.locale.ro.pivot.plugin.configurator.window.FilterValue',{
    override: 'Ext.pivot.plugin.configurator.window.FilterValue',

    titleText:      'Filtreaza valorile ({0})',
    fieldText:      'Arata inregistrarile pt care'
});