Ext.define('Ext.locale.ro.pivot.plugin.configurator.window.FilterTop',{
    override: 'Ext.pivot.plugin.configurator.window.FilterTop',

    titleText:      'Filtru Top 10 ({0})',
    fieldText:      'Arata',
    sortResultsText:'Sorteaza rezultatele'
});