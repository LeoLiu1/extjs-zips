Ext.define('Ext.locale.tr.pivot.plugin.configurator.window.FilterValue',{
    override: 'Ext.pivot.plugin.configurator.window.FilterValue',

    titleText:      'Değer filtre ({0})',
    fieldText:      'Öğeleri göster'
});