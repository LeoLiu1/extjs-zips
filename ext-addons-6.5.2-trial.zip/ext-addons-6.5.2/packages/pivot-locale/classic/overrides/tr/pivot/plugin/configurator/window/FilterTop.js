Ext.define('Ext.locale.tr.pivot.plugin.configurator.window.FilterTop',{
    override: 'Ext.pivot.plugin.configurator.window.FilterTop',

    titleText:      'En yüksek 10 sorgu ({0})',
    fieldText:      'Göster',
    sortResultsText:'Sonuç sırala'
});