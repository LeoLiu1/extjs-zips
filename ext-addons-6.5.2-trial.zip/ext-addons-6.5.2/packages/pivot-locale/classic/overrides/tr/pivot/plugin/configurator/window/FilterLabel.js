Ext.define('Ext.locale.tr.pivot.plugin.configurator.window.FilterLabel',{
    override: 'Ext.pivot.plugin.configurator.window.FilterLabel',

    titleText:          'Etiket sorgu ({0})',
    fieldText:          'Öğeleri göster hangi etiket için',
    caseSensitiveText:  'Harfe duyarlı'
});
