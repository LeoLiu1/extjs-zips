Ext.define('Ext.locale.it.pivot.plugin.configurator.window.FilterValue',{
    override: 'Ext.pivot.plugin.configurator.window.FilterValue',

    titleText:      'Valore filtro ({0})',
    fieldText:      'Visualizza elementi per i quali'
});