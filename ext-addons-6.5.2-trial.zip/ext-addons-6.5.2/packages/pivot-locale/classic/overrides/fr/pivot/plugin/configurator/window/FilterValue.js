Ext.define('Ext.locale.fr.pivot.plugin.configurator.window.FilterValue',{
    override: 'Ext.pivot.plugin.configurator.window.FilterValue',

    titleText:      'Filtre valeurs ({0})',
    fieldText:      'Afficher entrées avec'
});