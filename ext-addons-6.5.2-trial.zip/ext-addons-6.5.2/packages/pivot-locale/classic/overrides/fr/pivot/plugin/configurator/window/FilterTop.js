Ext.define('Ext.locale.fr.pivot.plugin.configurator.window.FilterTop',{
    override: 'Ext.pivot.plugin.configurator.window.FilterTop',

    titleText:      'Filtre Top 10 ({0})',
    fieldText:      'Afficher',
    sortResultsText:'Trier les résultats'
});