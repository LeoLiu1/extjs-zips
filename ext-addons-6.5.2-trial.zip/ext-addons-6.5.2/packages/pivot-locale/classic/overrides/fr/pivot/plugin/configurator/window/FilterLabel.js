Ext.define('Ext.locale.fr.pivot.plugin.configurator.window.FilterLabel',{
    override: 'Ext.pivot.plugin.configurator.window.FilterLabel',

    titleText:          'Filtre label ({0})',
    fieldText:          'Afficher entrées avec label',
    caseSensitiveText:  'Sensibilité à la casse'
});