Ext.define('Ext.locale.de.pivot.plugin.configurator.window.FilterTop',{
    override: 'Ext.pivot.plugin.configurator.window.FilterTop',

    titleText:      'Top 10 Filter ({0})',
    fieldText:      'Anzeigen',
    sortResultsText:'Sortiere Ergebnisse'
});
