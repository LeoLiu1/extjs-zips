Ext.define('Ext.locale.de.pivot.plugin.configurator.window.FilterValue',{
    override: 'Ext.pivot.plugin.configurator.window.FilterValue',

    titleText:      'Filter Werte ({0})',
    fieldText:      'Zeige Einträge mit'
});
