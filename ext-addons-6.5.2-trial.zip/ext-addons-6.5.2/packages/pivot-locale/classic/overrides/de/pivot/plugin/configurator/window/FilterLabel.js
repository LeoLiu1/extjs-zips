Ext.define('Ext.locale.de.pivot.plugin.configurator.window.FilterLabel',{
    override: 'Ext.pivot.plugin.configurator.window.FilterLabel',

    titleText:          'Filter Label ({0})',
    fieldText:          'Zeige Einträge mit Label',
    caseSensitiveText:  'Gross-/Kleinschreibung beachten'
});
