Ext.define('Ext.locale.da.pivot.plugin.configurator.window.FilterValue',{
    override: 'Ext.pivot.plugin.configurator.window.FilterValue',

    titleText:      'Value filter ({0})',
    fieldText:      'Vis elementer for hvilke'
});
