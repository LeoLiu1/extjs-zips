Ext.define('Ext.locale.da.pivot.plugin.configurator.window.FilterTop',{
    override: 'Ext.pivot.plugin.configurator.window.FilterTop',

    titleText:      'Top 10 filter ({0})',
    fieldText:      'Vis',
    sortResultsText:'Sorter resultat'
});
