Ext.define('Ext.locale.da.pivot.plugin.configurator.window.FilterLabel',{
    override: 'Ext.pivot.plugin.configurator.window.FilterLabel',

    titleText:          'Label filter ({0})',
    fieldText:          'Vis elementer for hvilke',
    caseSensitiveText:  'Case sensitive'
});
