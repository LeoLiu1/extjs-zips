Ext.define('Ext.locale.ru.pivot.plugin.configurator.window.FilterTop', {
    override: 'Ext.pivot.plugin.configurator.window.FilterTop',

    titleText:      'Топ 10 записей по ({0})',
    fieldText:      'Показать',
    sortResultsText:'Sort results'
});