Ext.define('Ext.locale.ru.pivot.plugin.configurator.window.FilterValue', {
    override: 'Ext.pivot.plugin.configurator.window.FilterValue',
    titleText:      'Фильтр по значению ({0})',
    fieldText:      'Показывать элементы, для которых'
});