Ext.define('Ext.locale.ru.pivot.plugin.configurator.window.FilterLabel', {
    override: 'Ext.pivot.plugin.configurator.window.FilterLabel',
    titleText:          'Фильтр по наименованию ({0})',
    fieldText:          'Показывать элементы с наименованием',
    caseSensitiveText:  'Учитывать регистр'
});