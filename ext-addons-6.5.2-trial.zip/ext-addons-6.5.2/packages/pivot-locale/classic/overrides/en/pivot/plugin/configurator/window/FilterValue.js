Ext.define('Ext.locale.en.pivot.plugin.configurator.window.FilterValue',{
    override: 'Ext.pivot.plugin.configurator.window.FilterValue',

    titleText:      'Value filter ({0})',
    fieldText:      'Show items for which'
});
