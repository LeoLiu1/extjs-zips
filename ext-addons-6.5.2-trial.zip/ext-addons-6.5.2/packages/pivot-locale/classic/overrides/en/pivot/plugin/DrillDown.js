Ext.define('Ext.locale.en.pivot.plugin.DrillDown', {
    override: 'Ext.pivot.plugin.DrillDown',

    textWindow: 'Drill down window'
});
